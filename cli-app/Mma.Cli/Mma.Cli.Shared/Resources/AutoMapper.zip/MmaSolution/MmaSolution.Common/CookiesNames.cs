namespace MmaSolution.Common
{
    public static class CookiesNames
    {
        public const string Token = "Token";
        public const string RefreshToken = "Refresh-Token";
        public const string Language = "Language";
    }
}
