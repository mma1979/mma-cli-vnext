﻿namespace MmaSolution.Core.Validations
{
    public class NotificationTypeValidator:AbstractValidator<NotificationTypeModifyModel>
    {

        public NotificationTypeValidator()
        {
           
        }


    }
}