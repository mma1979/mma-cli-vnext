using FluentValidation;

using MmaSolution.Core.Models.Notifications;

namespace MmaSolution.Core.Validations
{
    public class NotificationTypeValidator:AbstractValidator<NotificationTypeModifyModel>
    {

        public NotificationTypeValidator()
        {
           
        }


    }
}