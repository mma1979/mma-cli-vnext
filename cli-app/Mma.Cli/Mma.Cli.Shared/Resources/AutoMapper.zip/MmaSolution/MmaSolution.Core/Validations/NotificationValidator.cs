﻿namespace MmaSolution.Core.Validations
{
    public class NotificationValidator:AbstractValidator<NotificationModifyModel>
    {

        public NotificationValidator()
        {
           
        }


    }
}