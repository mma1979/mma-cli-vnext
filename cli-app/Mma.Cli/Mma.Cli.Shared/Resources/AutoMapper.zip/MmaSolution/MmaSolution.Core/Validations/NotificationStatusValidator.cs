using FluentValidation;

using MmaSolution.Core.Models.Notifications;

namespace MmaSolution.Core.Validations
{
    public class NotificationStatusValidator:AbstractValidator<NotificationStatusModifyModel>
    {

        public NotificationStatusValidator()
        {
           
        }


    }
}