namespace MmaSolution.Core.Enums
{
    public enum Languages:int
    {
        Arabic=1,
        English=2
    }
}
