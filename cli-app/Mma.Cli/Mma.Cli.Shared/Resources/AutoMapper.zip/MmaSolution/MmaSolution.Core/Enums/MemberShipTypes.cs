namespace MmaSolution.Core.Enums
{
    public enum MembershipTypes : int
    {
        Free = 1,
        Premium = 2,
        Gold = 3
    }
}
