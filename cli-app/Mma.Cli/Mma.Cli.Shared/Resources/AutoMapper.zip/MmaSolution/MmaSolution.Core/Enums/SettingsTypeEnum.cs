

namespace MmaSolution.Core.Enums
{
    public enum SettingsTypeEnum
    {
        Development = 0,
        Staging = 1,
        Production = 2
    }
}
