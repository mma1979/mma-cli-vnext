
namespace MmaSolution.Core.Enums;

public enum FeatureScope:int
{
    Global,
    User,
    Role,
    Resource
}