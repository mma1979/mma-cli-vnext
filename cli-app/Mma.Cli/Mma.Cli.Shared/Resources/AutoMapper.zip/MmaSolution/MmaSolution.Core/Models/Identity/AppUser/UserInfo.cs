﻿namespace MmaSolution.Core.Models.Identity.AppUser
{
    public class UserInfo
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
    }
}
