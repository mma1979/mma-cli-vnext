﻿global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.DependencyInjection.Extensions;
 
global using Stripe;
 
global using System;
global using System.Collections.Generic;
global using System.Threading.Tasks;
global using MmaSolution.Core.Models.Stripe;