namespace MmaSolution.AppApi.Infrastrcture.Listeners
{
    public static class NotificationsListner
    {
    }
}
