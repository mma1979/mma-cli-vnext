﻿namespace MmaSolution.AppApi.Hubs
{
    public class RabbitMQNotificationsHub:Hub
    {
    }
}
