﻿


namespace MmaSolution.Services.SmsService;

public class SmsService: ISmsService
{
    public Task Send(string to, string message)
    {
        throw new NotImplementedException();
    }
}
