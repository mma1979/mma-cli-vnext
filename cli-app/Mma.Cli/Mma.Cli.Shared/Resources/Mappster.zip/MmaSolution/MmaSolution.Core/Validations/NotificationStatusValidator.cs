namespace MmaSolution.Core.Validations
{
    public class NotificationStatusValidator:AbstractValidator<NotificationStatusModifyModel>
    {

        public NotificationStatusValidator()
        {
           
        }


    }
}