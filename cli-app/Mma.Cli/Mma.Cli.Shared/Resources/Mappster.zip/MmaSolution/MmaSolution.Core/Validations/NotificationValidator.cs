using FluentValidation;

using MmaSolution.Core.Models.Notifications;

namespace MmaSolution.Core.Validations
{
    public class NotificationValidator:AbstractValidator<NotificationModifyModel>
    {

        public NotificationValidator()
        {
           
        }


    }
}